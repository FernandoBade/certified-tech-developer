package MetodosAbstratos;

public class NovoAnimal {
}
