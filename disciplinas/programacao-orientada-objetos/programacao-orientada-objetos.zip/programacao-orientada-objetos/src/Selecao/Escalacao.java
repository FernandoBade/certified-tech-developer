package Selecao;

enum Escalacao {
    TITULAR,
    SUPLENTE,
    RESERVA
}
