package Checkpoint02;

public class ContaPoupanca extends Conta {


    public ContaPoupanca(String nomeCompleto, String cpf, String endereco, String profissao, double rendaMensal) {
        super(nomeCompleto, cpf, endereco, profissao, rendaMensal);
    }
}
