package AtividadeProva;

import java.time.LocalDate;

public abstract class Obra {

    private final String nomeDaObra;
    private final String endereco;
    private final LocalDate dataDeInicio;
    private LocalDate dataPrevisaoTermino;
    private LocalDate dataConclusaoFinal;

    //construtor completo
    public Obra(String nomeDaObra, String endereco, LocalDate dataDeInicio, LocalDate dataPrevisaoTermino, LocalDate dataConclusaoFinal) {
        this.nomeDaObra = nomeDaObra;
        this.endereco = endereco;
        this.dataDeInicio = dataDeInicio;
        this.dataPrevisaoTermino = dataPrevisaoTermino;
        this.dataConclusaoFinal = dataConclusaoFinal;
    }

    //construtor sem a data de conclus�o final
    public Obra(String endereco, LocalDate dataDeInicio, LocalDate dataPrevisaoTermino, String nomeDaObra) {
        this(nomeDaObra, endereco, dataDeInicio, dataPrevisaoTermino, null);
    }

    //getters e setters
    public String getNomeDaObra() {
        return nomeDaObra;
    }

    public String getEndereco() {
        return endereco;
    }

    public LocalDate getDataDeInicio() {
        return dataDeInicio;
    }

    public LocalDate getDataPrevisaoTermino() {
        return dataPrevisaoTermino;
    }

    public void setDataPrevisaoTermino(LocalDate dataPrevisaoTermino) {
        this.dataPrevisaoTermino = dataPrevisaoTermino;
    }

    public LocalDate getDataConclusaoFinal() {
        return dataConclusaoFinal;
    }

    public void setDataConclusaoFinal(LocalDate dataConclusaoFinal) {
        this.dataConclusaoFinal = dataConclusaoFinal;
    }

    //m�todo para imprimir os detalhes da obra
    @Override
    public String toString() {
         return "---------------------------------" + System.lineSeparator() +
                 "Nome da obra: " + nomeDaObra + System.lineSeparator() +
                "Endere�o: " + endereco + System.lineSeparator() +
                "Data de in�cio: " + dataDeInicio + System.lineSeparator() +
                "Data prevista para t�rmino: " + dataPrevisaoTermino + System.lineSeparator() +
                "Data de conclus�o: " + dataConclusaoFinal;
    }
}
