function retiraEspacosDeUmValor (valorRecebido) {
    return valorRecebido.trim();
}

function converteValorRecebidoParaMinusculo (valorRecebido) {
    return valorRecebido.toLowerCase();
}