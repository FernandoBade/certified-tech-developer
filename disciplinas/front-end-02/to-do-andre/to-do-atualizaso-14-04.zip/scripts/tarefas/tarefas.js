const tokenJwtusuarioLogado = localStorage.getItem("jwt")
onload = () => {
    if (!tokenJwtusuarioLogado) {
        location.href = "index.html"
    } else {
        buscaListaTarefas()
    }
}

//Encerra a sessão do usuário, retornando para a página de login

function finalizarSessao() {
    localStorage.removeItem('jwt')
    alert("Logout Realizado")
    window.location.href = "index.html"
}

//Adquire os dados de usuário da api

let endPointUsuario = "https://ctd-todo-api.herokuapp.com/v1/users/getMe";
let configuracaoRequisicao = {
    method: 'GET',
    headers: {
        'authorization': tokenJwtusuarioLogado
    }
}
fetch(endPointUsuario, configuracaoRequisicao).then(resultado => {
    return resultado.json();
}).then(resultado => {
    //adiciona o nome do usuário na parte superior direita da tela
    //a imagem de perfil é aleatória e muda a cada requisição, através do lorem picsum diretamente pelo CSS
    document.querySelector("#nome").innerText = `Olá, ${resultado.firstName}!`;

}).catch(erro => {
    console.log(erro);
}
);

//ativa as funções do 'render-tarefas.js' para renderizar as tarefas no HTML

function renderizarTareas(listaTarefas) {

    const tarefasPendentes = document.querySelector('.tarefas-pendentes');
    tarefasPendentes.innerHTML = "";
    const tarefasTerminadas = document.querySelector('.tarefas-terminadas');
    tarefasTerminadas.innerHTML = "";

    for (const tarefa of listaTarefas) {
        tarefa.completed ? renderizaTarefasTerminadas(tarefa) : renderizaTarefasPendentes(tarefa)
    }
}
